#!/bin/bash
#
# Script to initiate the processing pipelines for the Amazon project 
#

SCRIPT=`basename ${0}`
PIPELINE=${1}
ARGS=${2}
DATE=`date +%Y-%m-%d-%H%M%S`
RESULTS_DIR=/home/pulsar/RESULTS
PIPELINE_DIR=/home/pulsar/pipelines
PIPELINE_SCRIPTS_DIR=${PIPELINE_DIR}/pipeline_scripts
LOG_DIR=/home/pulsar/RESULTS/${SESSIONID}/logs
LOGFILE="${LOG_DIR}/${PIPELINE}-${DATE}.log"

# Check command line args
if [ $# -lt 2 ]; then
  echo
  echo -e "Usage: ${SCRIPT} <pipeline name> <config file> (OPTIONAL: <session ID>)\n"
  echo "This program initiates a processing pipeline,"
  echo -e "using a specified config file.\n" 
  echo -e "The following pipelines are available:\n"
  pipelines=`find ${PIPELINE_SCRIPTS_DIR} -maxdepth 1 -type f \
             -name "*.sh"`
  for i in $pipelines
    do
      echo "  `basename $i`"
    done
  echo
  exit 1
fi

if [ $# -eq 3 ]; then
  if [[ "${3}" =~ ^[0-9]+$ ]]; then
    SESSIONID=${3}
    LOG_DIR=/home/pulsar/RESULTS/${SESSIONID}/logs
  else
    echo "'$3' is not a valid session ID."
    exit 1
  fi
fi

echo "OK, using session ID ${SESSIONID}"

# Check that SESSIONID exists in the RESULTS directory
if [ ! -e ${RESULTS_DIR}/${SESSIONID} ]; then
  echo -e "\nERROR: Session ID '${SESSIONID}' is not yet ready for running"
  echo -e "a pipeline. Please run 'sort-dap-collection.sh' first.\n"
  exit 1
fi

# Create the log directory if it doesn't exist
if [ ! -e $LOG_DIR ]; then
  mkdir $LOG_DIR
fi

# Run pipeline
echo -e "\nRunning pipeline '${PIPELINE}'...\n"
time ${PIPELINE_SCRIPTS_DIR}/${PIPELINE} ${ARGS} 2>&1 | tee -a ${LOGFILE}

# Inform user of the location of the log file
echo
echo "Pipeline completed."
echo "The log file is:" 
echo "${LOGFILE}"
echo "Results can be found in:"
echo -e "${RESULTS_DIR}/${SESSIONID}/output\n"
