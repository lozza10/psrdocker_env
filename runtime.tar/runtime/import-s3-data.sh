#!/bin/bash
#
# Script to retrieve specified data set from AWS S3 bucket
#

SCRIPT=`basename ${0}`
DATANAME=${1}
DATE=`date +%Y-%m-%d-%H%M%S`
DATAROOT=/home/pulsar/DATA
S3BUCKET="pulsar-csiro"
S3FILELIST="${DATAROOT}/${SESSIONID}/data_lists/s3-files-${DATE}.lis"
LOCALFILELIST="${DATAROOT}/${SESSIONID}/data_lists/local-files-${DATE}.lis"
OUTPUTDIR="${DATAROOT}/${SESSIONID}/imported_data/${DATANAME}"

# Check command line args
if [ ${#} -ne 1 ]; then
  echo
  echo "Usage: ${SCRIPT} <Data_to_import/>"
  echo "e.g.   ${SCRIPT} P595/"
  echo -e "       ${SCRIPT} P595/2014APRS/\n"
  echo -e "NOTE: The trailing slash is required to import collections.\n"
  # List available datasets
  echo -e "The following datasets are available in S3 bucket 'pulsar-csiro':\n"
  aws s3 ls s3://${S3BUCKET} | grep PRE | awk '{print$2}'
  echo
  echo "Populating local data file list. Please wait..."
  find ${DATAROOT} -type f | grep -E '\.sf$|\.rf$|\.cf$' > ${LOCALFILELIST}
  echo
  echo "All files available locally are listed in:"
  echo -e "${LOCALFILELIST}\n"
  echo "Populating AWS S3 bucket file list. Please wait..."
  aws s3 ls s3://${S3BUCKET} --recursive > ${S3FILELIST}
  echo
  echo "All files available on S3 are listed in:"
  echo -e "${S3FILELIST}\n"
  exit 1
fi

# Check for non-existent DATA dir
if [ ! -d ${DATAROOT} ]; then
  echo "${DATAROOT} does not exist. Exiting."
  exit 1
fi

# Import the data from S3
if [[ ${DATANAME} == */ ]]; then
    aws s3 cp --recursive s3://${S3BUCKET}/${DATANAME} ${OUTPUTDIR}
else    
    aws s3 cp s3://${S3BUCKET}/${DATANAME} ${OUTPUTDIR}
fi
