#!/bin/bash
#
# Script to export the results to the AWS S3 bucket
#

SCRIPT=`basename ${0}`
DATANAME=${2}
RESULTSDIR=/home/pulsar/RESULTS/${SESSIONID}
S3BUCKET="pulsartest/RESULTS"

# Check command line args
if [ ${#} -ne 1 ]; then
  echo
  echo "Usage: ${SCRIPT} --run"
  echo
  echo "This program exports your results to the AWS S3 bucket."
  echo
  exit 1
fi

# Check for valid session ID
if ! [[ "${SESSIONID}" =~ ^[0-9]+$ ]]; then
  echo "'${SESSIONID}' is not a valid session ID."
  exit 1 
fi

# Check for non-existent DATA dir
if [ ! -d ${RESULTSDIR} ]; then
  echo "${RESULTSDIR} does not exist. Exiting."
  exit 1
fi

# Import the data from S3
aws s3 sync ${RESULTSDIR} s3://${S3BUCKET}/${SESSIONID}/
