#!/bin/bash
#
# Program to build imported software packages 
#
# The following packages contain GPL licences that are incompatible
# with licences of default packages on the virtual machine 
#
# fftw
# psrcat
# tempo2
# TempoNest
#

# Define runtime and error log ------------------------------------
BUILD_ERR_LOG="/home/pulsar/runtime/build-err.log"
BUILD_RUN_LOG="/home/pulsar/runtime/build-run.log"
[ ! -e ${BUILD_ERR_LOG} ] || /bin/rm ${BUILD_ERR_LOG}
[ ! -e ${BUILD_RUN_LOG} ] || /bin/rm ${BUILD_RUN_LOG}
exec 2> ${BUILD_ERR_LOG}

# Define git repositories to clone --------------------------------
# NOTE: github url required for status check
FFTW_URL="https://github.com/FFTW/fftw3"
TEMPONEST_URL="https://github.com/LindleyLentati/TempoNest"
FFTW_REPO="${FFTW_URL}.git"
TEMPO2_REPO="https://bitbucket.org/psrsoft/tempo2.git"
TEMPONEST_REPO="${TEMPONEST_URL}.git"

# Define other package packages and locations ---------------------
PSRCAT_TAR="psrcat_pkg.tar.gz"
PSRCAT_URL="http://www.atnf.csiro.au/research/pulsar/psrcat/download.html"
PSRCAT_PKG="http://www.atnf.csiro.au/research/pulsar/psrcat/downloads/${PSRCAT_TAR}"

# Define git branches to checkout ---------------------------------
TEMPO2_BRANCH="ltlBranch"

# Define git commit hashes to checkout ----------------------------
FFTW_COMMIT_HASH="2ed010c62b1bc8ca6b23bfda2e09b8c28e1e8bcc"
TEMPO2_COMMIT_HASH="bdfca43881e7d06958a7eaa294493406970758ec"
TEMPONEST_COMMIT_HASH="6a5e9982c914e21551399e21ffd439a52b61d584"

# Functions -------------------------------------------------------
# check repository url status
check_url_status() {
  url="${1}"
  status=`curl -o /dev/null --silent --head --write-out '%{http_code}\n' ${url}`
  echo ${status}
}

# error checking
fatal() { echo ${1}; exit 1; }
warn() { echo ${1}; }

# check for compile errors
check_compile() {
  stat=0
  if [ -e ${BUILD_ERR_LOG} ]; then
    stat=`grep -icE 'compilation terminated|fatal error|Error is not recoverable'\
 ${BUILD_ERR_LOG}`
  fi
  echo ${stat}
}

# log runtime output
log_output() {
  while [ ${#} -gt 0 ]
  do
    echo -e ${1}
    [ "X" = "X${BUILD_RUN_LOG}" ] || echo -e ${1} >> "${BUILD_RUN_LOG}"
    shift
  done
}

# clone the repository
clone() {
  case ${1} in
         fftw) repo=${FFTW_REPO}
               ;;
       tempo2) repo=${TEMPO2_REPO}
               ;;
    temponest) repo=${TEMPONEST_REPO}
               ;;
  esac
  git clone ${repo} | tee -a ${BUILD_RUN_LOG}
}

# checkout a particular branch or commit
checkout() {
  case ${1} in
         fftw) case ${2} in
                 branch) 
                 ;;
                 commit) arg=${FFTW_COMMIT_HASH}
                 ;;
               esac
               ;;
       tempo2) case ${2} in
                 branch) arg=${TEMPO2_BRANCH}
                 ;;
                 commit) arg=${TEMPO2_COMMIT_HASH}
                 ;;
               esac                 
               ;;
    temponest) case ${2} in
                 branch) arg=${TEMPONEST_REPO}
                 ;;
                 commit) arg=${TEMPONEST_COMMIT_HASH}
                 ;;
               esac
               ;;
  esac
  git checkout ${arg} | tee -a ${BUILD_RUN_LOG}
}

# compile 
compile() {
  case ${1} in
         fftw) sh bootstrap.sh | tee -a ${BUILD_RUN_LOG}
               case ${2} in
                 single) ./configure --enable-maintainer-mode --prefix=${ASTROSOFT_IMPORTED} --enable-float --enable-threads --enable-shared CFLAGS="-fPIC -I${ASTROSOFT_IMPORTED}/fftw3/api" FFLAGS=-fPIC CXXFLAGS="-fPIC -I${ASTROSOFT_IMPORTED}/fftw3/api" | tee -a ${BUILD_RUN_LOG}
                         ;;
                 double) ./configure --enable-maintainer-mode --prefix=${ASTROSOFT_IMPORTED} CFLAGS="-fPIC -I${ASTROSOFT_IMPORTED}/fftw3/api" FFLAGS=-fPIC CXXFLAGS="-fPIC -I${ASTROSOFT_IMPORTED}/fftw3/api" | tee -a ${BUILD_RUN_LOG}
                         ;;
               esac 
               ;;
       tempo2) ./bootstrap | tee -a ${BUILD_RUN_LOG}
               ./configure --prefix=${ASTROSOFT_IMPORTED} --with-cfitsio-dir=${ASTROSOFT_DEFAULT} --with-fftw3-dir=${ASTROSOFT_IMPORTED} F77=gfortran CFLAGS=-fPIC FFLAGS=-fPIC CXXFLAGS="-I${ASTROSOFT_DEFAULT}/include -I${ASTROSOFT_IMPORTED}/include -I${ASTROSOFT_DEFAULT}/pgplot_build" | tee -a ${BUILD_RUN_LOG}
               ;;
    temponest) ./autogen.sh | tee -a ${BUILD_RUN_LOG}
               ./configure CXXFLAGS="-I${ASTROSOFT_DEFAULT}/include -I${ASTROSOFT_IMPORTED}/include -I./lbfgs/include -fopenmp" LDFLAGS="-L${ASTROSOFT_DEFAULT}/lib -L${ASTROSOFT_IMPORTED}/lib -L/usr/lib64/mpich/lib" LIBS="-lfmpich -lmpich -lfftw3" | tee -a ${BUILD_RUN_LOG}
               ;;
  esac
}

# build
build() {
  case ${1} in
    fftw|temponest) make | tee -a ${BUILD_RUN_LOG}
                    ;;
            tempo2) make | tee -a ${BUILD_RUN_LOG}
                    make plugins | tee -a ${BUILD_RUN_LOG}
                    make unsupported | tee -a ${BUILD_RUN_LOG}
                    ;;
            psrcat) source makeit | tee -a ${BUILD_RUN_LOG}
                    ;;
         multinest) make | tee -a ${BUILD_RUN_LOG}
                    make libnest3.so | tee -a ${BUILD_RUN_LOG}
                    ;;
  esac
}

# install
install() {
  case ${1} in
            psrcat) cp psrcat ${SRC_DIR}/bin | tee -a ${BUILD_RUN_LOG}
                    ;;
            tempo2) make install | tee -a ${BUILD_RUN_LOG}
                    make plugins-install | tee -a ${BUILD_RUN_LOG}
                    cp unsupported_plugins/toasim/.libs/*.t2 T2runtime/plugins/ | tee -a ${BUILD_RUN_LOG}
                    ;;
    temponest|fftw) make install | tee -a ${BUILD_RUN_LOG}
                    ;;
  esac
}

# clean up
clean() {
  case ${1} in
    *) make clean | tee -a ${BUILD_RUN_LOG}
  esac
}

# Sanity checks ---------------------------------------------------
# check for and define source directory
SRC_DIR=${ASTROSOFT_IMPORTED}
[ -d ${SRC_DIR} ] || mkdir -p ${SRC_DIR}/bin

# check repositories URLs
log_output "\nChecking repository URLs are accessible..."
for i in ${FFTW_URL} ${PSRCAT_URL} ${TEMPO2_REPO} ${TEMPONEST_URL} 
do
  stat=`check_url_status ${i}`
  log_output "URL: ${i} STATUS: ${stat}"
  [ ${stat} -eq 200 ] || \
  fatal "The following repository does not exist: '${i}'. Exiting."
done

# Main ------------------------------------------------------------
log_output "\nStarting the build..."
cd ${SRC_DIR}

# FFTW - Fast Fourier Transform routines #
log_output "\n-->> Building FFTW..."

# clone the repo
clone fftw

# check out the required commit
cd fftw3
checkout fftw

# run bootstrap
compile fftw

# compile single precision library
compile fftw single

# build
build fftw

# check build status
#compile_status=`check_compile`
#[ ${compile_status} -eq 0 ] ||\
#fatal "ERROR: Building FFTW failed. See ${BUILD_ERR_LOG} for details. \ 
#Exiting."

# install
install fftw

# clean up
clean fftw
rm -rf ${BUILD_ERR_LOG}

# compile double precision library
compile fftw double 

# build
build fftw

# check build status
#compile_status=`check_compile`
#[ ${compile_status} -eq 0 ] ||\
#fatal "ERROR: Building FFTW failed. See ${BUILD_ERR_LOG} for details. \ 
#Exiting."

# install
install fftw

# clean up
clean fftw
rm -rf ${BUILD_ERR_LOG}

cd ${SRC_DIR}


# PSRCAT - The ATNF Pulsar Catalogue #
log_output "\n-->> Building PSRCAT..."

# remove existing packages
[ ! -e ${PSRCAT_TAR} ] || /bin/rm ${PSRCAT_TAR}

# get package
wget ${PSRCAT_PKG}

# unpack
tar -zxvf ${PSRCAT_TAR}

# build
cd psrcat_tar
build psrcat

# check build status
compile_status=`check_compile`
[ ${compile_status} -eq 0 ] ||\
fatal "ERROR: Building PSRCAT failed. See ${BUILD_ERR_LOG} for details. Exiting."

# install
install psrcat

# clean up
rm -rf ${BUILD_ERR_LOG}

cd ${SRC_DIR}


# TEMPO2 - Pulsar timing analysis software # 
log_output "\n-->> Building TEMPO2..."

# clone the repo
clone tempo2

# check out the required branch/commit
cd tempo2
checkout tempo2 branch
checkout tempo2 commit

# compile
compile tempo2

# build
build tempo2

# check build status
compile_status=`check_compile`
[ ${compile_status} -eq 0 ] ||\
fatal "ERROR: Building TEMPO2 failed. See ${BUILD_ERR_LOG} for details. Exiting."

# install
install tempo2

# clean up
clean tempo2
rm -rf ${BUILD_ERR_LOG}

cd ${SRC_DIR}


# TEMPONEST - Bayesian analysis tool for pulsar timing #
log_output "\n-->> Building TEMPONEST..."

# clone the repo
clone temponest

# check out the required branch/commit
cd TempoNest
checkout temponest commit

# build MultiNest
cd MultiNest
mv Makefile MakefileMPI
cp MakefileNoMPI Makefile
build multinest

# check build status
compile_status=`check_compile`
[ ${compile_status} -eq 0 ] ||\
fatal "ERROR: Building MULTINEST failed. See ${BUILD_ERR_LOG} for details. Exiting."
cd ../

# clean up
rm -rf ${BUILD_ERR_LOG}

# compile temponest
compile temponest

# build
build temponest

# check build status
compile_status=`check_compile`
[ ${compile_status} -eq 0 ] ||\
fatal "ERROR: Building TEMPONEST failed. See ${BUILD_ERR_LOG} for details. Exiting."

# install
install temponest

# clean up
clean temponest
rm -rf ${BUILD_ERR_LOG}

cd ${SRC_DIR}


# Finish up
echo -e "\nBuild complete. Build run log is '${BUILD_RUN_LOG}'."
if [ -e ${BUILD_ERR_LOG} ]; then
  echo -e "                Build error log is '${BUILD_ERR_LOG}'.\n"
fi
