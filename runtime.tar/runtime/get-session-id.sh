#!/bin/bash
#
# Script to retrieve the user's session ID
#

echo
echo -e "Your session ID is: `echo ${SESSIONID}`\n"
