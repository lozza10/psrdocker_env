#!/bin/bash
#
# Script to sort the DAP collection into source directories, and populate
# file lists for processing by the AWS fold-mode pipeline.
#
# A DAP pulsar collection contains raw, preprocessed and thumbnails directories.
# The DR2 pipeline requires directory structure based on pulsar (J) name.
#
# This script simply creates the required directory structure in 
# /home/pulsar/RESULTS/<SESSIONID>, containing softlinks to the files in
# the data directory, /home/pulsar/DATA/<SESSIONID>/imported_data
#

SCRIPT=`basename ${0}`
DATA_ROOT=/home/pulsar/DATA/${SESSIONID}
DATA_IN=${DATA_ROOT}/imported_data
DATA_OUT=/home/pulsar/RESULTS/${SESSIONID}
LIST_DIR=${DATA_ROOT}/data_lists
PROCESS_DIR=${DATA_ROOT}/sorted_data
CAL_DIR=${PROCESS_DIR}/cals
IGNORED_FILE_LIST=${LIST_DIR}/ignored_files.lis
NCF=0
NRF=0
NSF=0
NFLUXCAL=0
NPCMCAL=0
IGNORED=0

# Check command line args
if [ $# -ne 1 ]; then
  while [ "${1}" != "--run" ]
  do 
    echo
    echo "Usage: ${SCRIPT} --run"
    echo
    echo -e "This program sorts data into directories by pulsar Jname.\n"
    exit 1
  done
fi

# Check session ID is set
if [ -z ${SESSIONID} ]; then
  echo "ERROR: SESSIONID variable is not set. Exiting."
  exit 1
else
  echo "OK: using session ID ${SESSIONID}"
fi

# Check for non-existent DATA dirs
if [ ! -d $DATA_IN ]; then
  echo "$DATA_IN does not exist. Exiting."
  exit 1
fi

# Check for existence of list of ignored files
[ ! -e ${IGNORED_FILE_LIST} ] || /bin/rm ${IGNORED_FILE_LIST}

# Create directory structure
if [ ! -d $DATA_OUT ]; then
  echo "Creating ${DATA_OUT}"
  mkdir ${DATA_OUT}
  echo "Creating ${DATA_OUT}/output"
  mkdir ${DATA_OUT}/output
  echo "Creating ${PROCESS_DIR}"
  mkdir ${PROCESS_DIR}
  echo "Creating ${PROCESS_DIR}/templates"
  mkdir ${PROCESS_DIR}/templates
  echo "Creating ${PROCESS_DIR}/ephem"
  mkdir ${PROCESS_DIR}/ephem
  echo "Creating ${CAL_DIR}"
  mkdir -p ${CAL_DIR}/fluxcal
  mkdir -p ${CAL_DIR}/pcm
fi

for file in `find ${DATA_IN} -type f`
  do
    filename=`basename ${file}`
    echo "Found ${filename}..."

    # get file extension
    ext=`echo ${filename} | sed 's/.*\.//'`

    # match and process accordingly
    case ${ext} in
      # fold|cal file
      rf|cf) 
	jname=`vap -c name ${file} | awk 'NR==2 {print$2}'`
	echo "${filename}: source ${jname}"
        # populate directory structure
        [ -e ${PROCESS_DIR}/${jname} ] || mkdir ${PROCESS_DIR}/${jname}
        ln -s ${file} ${PROCESS_DIR}/${jname}/${filename}
        # populate file listing for RM software and increment count
        case ${ext} in
          rf) echo "${file} ${jname}" >> ${LIST_DIR}/filelist.lis
              NRF=$((NRF+1))
          ;;
          cf) NCF=$((NCF+1))
          ;;
        esac
      ;;
      # search mode file 
      sf)
	jname=`vap -c name ${file} | awk 'NR==2 {print$2}'`
        echo "${filename}: source ${jname} [search mode]"
        # populate directory structure
	[ -e ${PROCESS_DIR}/searchmode ] || mkdir ${PROCESS_DIR}/searchmode
        [ -e ${PROCESS_DIR}/searchmode/${jname} ] || mkdir ${PROCESS_DIR}/searchmode/${jname}
        ln -s ${file} ${PROCESS_DIR}/searchmode/${jname}/${filename}
        # count matches 
        NSF=$((NSF+1))
      ;;
      # flux cals
      fluxcal)
        echo "${filename}: [flux cal]"
        ln -s ${file} ${CAL_DIR}/fluxcal/${filename}
        # count matches 
        NFLUXCAL=$((NFLUXCAL+1))
      ;;
      # pcm cals
      pcm)
        echo "${filename}: [pcm cal]"
        ln -s ${file} ${CAL_DIR}/pcm/${filename}
        # count matches 
        NPCMCAL=$((NPCMCAL+1))
      ;;
      # other file extensions are invalid and skipped
      *)
	echo "'${filename}' is not a cal, fold- or search-mode PSRFITS file and will be ignored"
        echo ${filename} >> ${IGNORED_FILE_LIST} 
        IGNORED=$((IGNORED+1))
      ;;
    esac
   
  done

# display stats
echo
echo "No. of cal (.cf) files found: ${NCF}"
echo "No. of fold-mode (.rf) files found: ${NRF}"
echo "No. of search-mode (.sf) files found: ${NSF}"
echo "No. of flux cal (.fluxcal) files found: ${NFLUXCAL}"
echo "No. of pcm cal (.pcm) files found: ${NPCMCAL}"
if [ ${IGNORED} -gt 0 ]; then
  echo -e "No. of files ignored: ${IGNORED}\n"
  echo -e "See ${IGNORED_FILE_LIST} for details.\n"
fi 
# create source list for processing, ignoring filenames containing underscores and searchmode directory
echo "Creating source list '${LIST_DIR}/sourcelist.lis'"
ls -I "*_*" -I "searchmode" -I "cals" -I "ephem" -I "templates" \
${PROCESS_DIR} > ${LIST_DIR}/sourcelist.lis
if [ -e ${PROCESS_DIR}/searchmode ]; then
  echo "Creating searchmode source list '${LIST_DIR}/searchmode_sourcelist.lis'"
  ls -I ${PROCESS_DIR}/searchmode > ${LIST_DIR}/searchmode_sourcelist.lis
fi
echo 
