#!/bin/bash
#
# Script to get versions of installed software
#

echo
echo "Getting installed software versions..."

v_kernel=`uname -r`
v_cfitsio=`grep Version ${ASTROSOFT_DEFAULT}/cfitsio/docs/changes.txt | head -1`
v_psrcat_soft=`psrcat -v | awk 'NR==1 {print}'`
v_psrcat_cat=`psrcat -v | awk 'NR==2 {print}' | sed 's/ =/:/g'`
v_pgplot="5.2"
v_mpi4py=`ls ${ASTROSOFT_DEFAULT} | grep -w 'mpi4py' | sed 's/mpi4py-//'`
v_ionrm=`git --git-dir=${ASTROSOFT_DEFAULT}/ionospheric_RM/.git log \
       --oneline --abbrev-commit --all | awk 'NR==1 {print$1}'`
v_fftw=`git --git-dir=${ASTROSOFT_IMPORTED}/fftw3/.git log \
       --oneline --abbrev-commit --all | awk 'NR==1 {print$1}'`
v_tempo2=`git --git-dir=${ASTROSOFT_IMPORTED}/tempo2/.git log \
       --oneline --abbrev-commit --all | awk 'NR==1 {print$1}'`
v_psrchive=`git --git-dir=${ASTROSOFT_DEFAULT}/psrchive/.git log \
       --oneline --abbrev-commit --all | awk 'NR==1 {print$1}'`
v_aws=`git --git-dir=/home/pulsar/pipelines/amazon_fold_pipeline/.git log \
       --oneline --abbrev-commit --all | awk 'NR==1 {print$1}'`
v_temponest=`git --git-dir=${ASTROSOFT_IMPORTED}/TempoNest/.git log \
       --oneline --abbrev-commit --all | awk 'NR==1 {print$1}'`
v_pyfits=`git --git-dir=${ASTROSOFT_DEFAULT}/PyFITS/.git log \
       --oneline --abbrev-commit --all | awk 'NR==1 {print$1}'`

echo
echo "VM build:   ${VMBUILD}" 
echo "VM version: ${VMVERSION}" 
echo "Build date: ${BUILDDATE}"
echo "Kernel:     ${v_kernel}"
echo
echo "You have the following versions (or git commit hashes) of software installed:"
echo
echo "cfitsio:        ${v_cfitsio}"
echo "psrcat:         ${v_psrcat_soft} ${v_psrcat_cat}"
echo "pgplot:         ${v_pgplot}"
echo "mpi4py:         ${v_mpi4py}"
echo "fftw:           HEAD * ${v_fftw}"
echo "ionospheric RM: HEAD * ${v_ionrm}"
echo "tempo2:         HEAD * ${v_tempo2}"
echo "psrchive:       HEAD * ${v_psrchive}"
echo "aws pipeline:   HEAD * ${v_aws}"
echo "TempoNest:      HEAD * ${v_temponest}"
echo "PyFITS:         HEAD * ${v_pyfits}"
echo
